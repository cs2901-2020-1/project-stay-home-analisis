package com.stayhome.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StayhomeApplicationTests {

	@Test
	void contextLoads() {
	}

}
